﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets_Inheritance
{
    class Cat : Pet
    {
        private string furcolour;
        private int numOfWhiskers;

        public string Furcolour { get => furcolour; set => furcolour = value; }
        public int NumOfWhiskers { get => numOfWhiskers; set => numOfWhiskers = value; }
    }
}

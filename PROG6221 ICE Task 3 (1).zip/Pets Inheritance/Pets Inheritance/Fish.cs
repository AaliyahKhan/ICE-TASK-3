﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets_Inheritance
{
    class Fish : Pet
    {
        private string scaleColour;
        private int numOfGills;

        public string ScaleColour { get => scaleColour; set => scaleColour = value; }
        public int NumOfGills { get => numOfGills; set => numOfGills = value; }
    }
}

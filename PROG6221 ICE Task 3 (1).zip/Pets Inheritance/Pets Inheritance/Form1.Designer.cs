﻿
namespace Pets_Inheritance
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AnimalSelectLb = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.EyeColLb = new System.Windows.Forms.Label();
            this.TailLengthLb = new System.Windows.Forms.Label();
            this.BreedLb = new System.Windows.Forms.Label();
            this.EyeColTextBox = new System.Windows.Forms.TextBox();
            this.TailLengthTextBox = new System.Windows.Forms.TextBox();
            this.BreedTextBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ItemBTextBox = new System.Windows.Forms.TextBox();
            this.ItemATextBox = new System.Windows.Forms.TextBox();
            this.ItemB = new System.Windows.Forms.Label();
            this.ItemA = new System.Windows.Forms.Label();
            this.saveBt = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // AnimalSelectLb
            // 
            this.AnimalSelectLb.AutoSize = true;
            this.AnimalSelectLb.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AnimalSelectLb.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AnimalSelectLb.Location = new System.Drawing.Point(12, 9);
            this.AnimalSelectLb.Name = "AnimalSelectLb";
            this.AnimalSelectLb.Size = new System.Drawing.Size(249, 40);
            this.AnimalSelectLb.TabIndex = 0;
            this.AnimalSelectLb.Text = "Select an animal:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Bird",
            "Cat",
            "Dog",
            "Fish",
            "Snake"});
            this.comboBox1.Location = new System.Drawing.Point(268, 23);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(164, 23);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // EyeColLb
            // 
            this.EyeColLb.AutoSize = true;
            this.EyeColLb.Location = new System.Drawing.Point(13, 60);
            this.EyeColLb.Name = "EyeColLb";
            this.EyeColLb.Size = new System.Drawing.Size(67, 15);
            this.EyeColLb.TabIndex = 2;
            this.EyeColLb.Text = "Eye Colour:";
            // 
            // TailLengthLb
            // 
            this.TailLengthLb.AutoSize = true;
            this.TailLengthLb.Location = new System.Drawing.Point(12, 89);
            this.TailLengthLb.Name = "TailLengthLb";
            this.TailLengthLb.Size = new System.Drawing.Size(67, 15);
            this.TailLengthLb.TabIndex = 3;
            this.TailLengthLb.Text = "Tail Length:";
            // 
            // BreedLb
            // 
            this.BreedLb.AutoSize = true;
            this.BreedLb.Location = new System.Drawing.Point(39, 118);
            this.BreedLb.Name = "BreedLb";
            this.BreedLb.Size = new System.Drawing.Size(40, 15);
            this.BreedLb.TabIndex = 4;
            this.BreedLb.Text = "Breed:";
            // 
            // EyeColTextBox
            // 
            this.EyeColTextBox.Location = new System.Drawing.Point(86, 60);
            this.EyeColTextBox.Name = "EyeColTextBox";
            this.EyeColTextBox.Size = new System.Drawing.Size(175, 23);
            this.EyeColTextBox.TabIndex = 5;
            // 
            // TailLengthTextBox
            // 
            this.TailLengthTextBox.Location = new System.Drawing.Point(86, 89);
            this.TailLengthTextBox.Name = "TailLengthTextBox";
            this.TailLengthTextBox.Size = new System.Drawing.Size(175, 23);
            this.TailLengthTextBox.TabIndex = 6;
            // 
            // BreedTextBox
            // 
            this.BreedTextBox.Location = new System.Drawing.Point(86, 118);
            this.BreedTextBox.Name = "BreedTextBox";
            this.BreedTextBox.Size = new System.Drawing.Size(175, 23);
            this.BreedTextBox.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.ItemBTextBox);
            this.panel1.Controls.Add(this.ItemATextBox);
            this.panel1.Controls.Add(this.ItemB);
            this.panel1.Controls.Add(this.ItemA);
            this.panel1.Location = new System.Drawing.Point(13, 147);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(248, 112);
            this.panel1.TabIndex = 8;
            // 
            // ItemBTextBox
            // 
            this.ItemBTextBox.Location = new System.Drawing.Point(3, 66);
            this.ItemBTextBox.Name = "ItemBTextBox";
            this.ItemBTextBox.Size = new System.Drawing.Size(172, 23);
            this.ItemBTextBox.TabIndex = 3;
            // 
            // ItemATextBox
            // 
            this.ItemATextBox.Location = new System.Drawing.Point(4, 22);
            this.ItemATextBox.Name = "ItemATextBox";
            this.ItemATextBox.Size = new System.Drawing.Size(172, 23);
            this.ItemATextBox.TabIndex = 2;
            this.ItemATextBox.TextChanged += new System.EventHandler(this.ItemATextBox_TextChanged);
            // 
            // ItemB
            // 
            this.ItemB.AutoSize = true;
            this.ItemB.Location = new System.Drawing.Point(4, 48);
            this.ItemB.Name = "ItemB";
            this.ItemB.Size = new System.Drawing.Size(10, 15);
            this.ItemB.TabIndex = 1;
            this.ItemB.Text = ".";
            // 
            // ItemA
            // 
            this.ItemA.AutoSize = true;
            this.ItemA.Location = new System.Drawing.Point(4, 4);
            this.ItemA.Name = "ItemA";
            this.ItemA.Size = new System.Drawing.Size(10, 15);
            this.ItemA.TabIndex = 0;
            this.ItemA.Text = ".";
            // 
            // saveBt
            // 
            this.saveBt.Location = new System.Drawing.Point(268, 275);
            this.saveBt.Name = "saveBt";
            this.saveBt.Size = new System.Drawing.Size(75, 23);
            this.saveBt.TabIndex = 9;
            this.saveBt.Text = "Save";
            this.saveBt.UseVisualStyleBackColor = true;
            this.saveBt.Click += new System.EventHandler(this.saveBt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 317);
            this.Controls.Add(this.saveBt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.BreedTextBox);
            this.Controls.Add(this.TailLengthTextBox);
            this.Controls.Add(this.EyeColTextBox);
            this.Controls.Add(this.BreedLb);
            this.Controls.Add(this.TailLengthLb);
            this.Controls.Add(this.EyeColLb);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.AnimalSelectLb);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AnimalSelectLb;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label EyeColLb;
        private System.Windows.Forms.Label TailLengthLb;
        private System.Windows.Forms.Label BreedLb;
        private System.Windows.Forms.TextBox EyeColTextBox;
        private System.Windows.Forms.TextBox TailLengthTextBox;
        private System.Windows.Forms.TextBox BreedTextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label ItemA;
        private System.Windows.Forms.TextBox ItemBTextBox;
        private System.Windows.Forms.TextBox ItemATextBox;
        private System.Windows.Forms.Label ItemB;
        private System.Windows.Forms.Button saveBt;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets_Inheritance
{
    class Pet
    {
        private string EyeColour;
        private int TailLength;
        private string Breed;

        public string EyeColour1 { get => EyeColour; set => EyeColour = value; }
        public int TailLength1 { get => TailLength; set => TailLength = value; }
        public string Breed1 { get => Breed; set => Breed = value; }
    }
}

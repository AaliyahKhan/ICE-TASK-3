﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets_Inheritance
{
    class Dog : Pet
    {
        private string furType;
        private string furColour;

        public string FurType { get => furType; set => furType = value; }
        public string FurColour { get => furColour; set => furColour = value; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets_Inheritance
{
    class Snake : Pet
    {
        private string scaleColour;
        private int fangLength;

        public string ScaleColour { get => scaleColour; set => scaleColour = value; }
        public int FangLength { get => fangLength; set => fangLength = value; }
    }
}

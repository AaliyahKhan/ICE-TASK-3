﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets_Inheritance
{
    class Bird : Pet
    {
        private string featherColour;
        private int wingspan;

        public string FeatherColour { get => featherColour; set => featherColour = value; }
        public int Wingspan { get => wingspan; set => wingspan = value; }
    }
}
